#!/bin/bash
echo "**** Bu script Aylinux için Cihan Alkan tarafından düzenlenmiştir. ****"
echo
echo "	EBYS Ayarları Yapılıyor..."
echo "1. Java deployment.properties güncelleniyor."
kulad="$(whoami)"
filename="/home/$kulad/.java/deployment/deployment.properties"
policy="/home/$kulad/.java.policy"

if test -e  $filename
then
	echo "deployment.security.use.user.home.java.policy=true" >>  "$filename"
    	mv "/home/$kulad/.java/deployment/deployment.properties" "/home/$kulad/.java/deployment/deployment.properties.eski"
	touch "$filename"
	echo "deployment.security.use.user.home.java.policy=true" >> "$filename"
	cat "/home/$kulad/.java/deployment/deployment.properties.tmp" >> "$filename"
	
fi
echo "2. Java güvenlik ayarları (exception sites) güncelleniyor."
filename="/home/$kulad/.java/deployment/security/exception.sites"
if test -e  $filename
then
	echo "http://tsim.saglik.gov.tr" >>  "$filename"  
	echo "https://tsim.saglik.gov.tr" >>  "$filename" 
	echo "http://tsim1.saglik.gov.tr/tsim2.htm" >>  "$filename" 	
	echo "http://ckys.saglik.gov.tr" >>  "$filename"  
	echo "http://ckyshst.saglik.gov.tr" >>  "$filename"  
	echo "https://tsim1.saglik.gov.tr/tsim2.htm" >>  "$filename" 	
	echo "https://ckys.saglik.gov.tr" >>  "$filename"  
	echo "https://ckyshst.saglik.gov.tr" >>  "$filename" 
    	
else
	touch "$filename"	
	echo "http://tsim.saglik.gov.tr" >>  "$filename"  
	echo "https://tsim.saglik.gov.tr" >>  "$filename" 
	echo "http://tsim1.saglik.gov.tr/tsim2.htm" >>  "$filename" 	
	echo "http://ckys.saglik.gov.tr" >>  "$filename"  
	echo "http://ckyshst.saglik.gov.tr" >>  "$filename" 
	echo "https://tsim1.saglik.gov.tr/tsim2.htm" >>  "$filename" 	
	echo "https://ckys.saglik.gov.tr" >>  "$filename"  
	echo "https://ckyshst.saglik.gov.tr" >>  "$filename"  	
fi

echo "3. Java Policy onarılıyor."
if test -e  $policy
then
	echo "/home/$kulad/.java.policy=true" >>  "$policy"
    	mv "//home/$kulad/.java.policy" "//home/$kulad/.java.policy.eski"
	touch "$policy"
	echo "grant {" >>  "$policy"
	echo "  permission java.security.AllPermission;" >>  "$policy"
	echo "};" >>  "$policy"  	
fi

echo "**** İşlemler bitmiştir. EBYS yi sorunsuzce kullanabilirsiniz.****"
