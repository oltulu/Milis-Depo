#!/bin/bash
echo "**** Bu script Aylinux için Cihan Alkan tarafından düzenlenmiştir. ****"
echo
echo "	UYAP Ayarları Yapılıyor..."
kulad="$(whoami)"
filename="/home/$kulad/.uki/acilisDegerleri.xml"
uki="/home/$kulad/.uki/acilisDegerleri.xml"

rm -fr /home/$kulad/.uki	
echo "**** İşlemler bitmiştir. UYAP'ı sorunsuzce kullanabilirsiniz.****"
