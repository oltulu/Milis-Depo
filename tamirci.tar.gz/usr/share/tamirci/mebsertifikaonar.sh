#!/bin/bash
echo "**** Bu script Aylinux için Cihan Alkan tarafından Düzenlenmiştir. ****"
echo "Meb Sertifikası indirilip kurulacak."
cd /usr/share/ca-certificates
sudo wget http://sertifika.meb.gov.tr/MEB_SERTIFIKASI.cer
sudo openssl x509 -inform DER -in MEB_SERTIFIKASI.cer -out MEB_SERTIFIKASI.crt
sudo trust extract-compat
echo "**** İşlemler bitmiştir. MEB Sertifikası Sisteminize kuruldu. ****"




