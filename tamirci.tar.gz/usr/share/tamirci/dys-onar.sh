#!/bin/bash
echo "**** Bu script Aylinux için Cihan Alkan tarafından düzenlenmiştir. ****"
echo
echo "	DYS Ayarları Yapılıyor..."
echo "1. Java deployment.properties güncelleniyor."
kulad="$(whoami)"
filename="/home/$kulad/.java/deployment/deployment.properties"
policy="/home/$kulad/.java.policy"

if test -e  $filename
then
	echo "deployment.security.use.user.home.java.policy=true" >>  "$filename"
    	mv "/home/$kulad/.java/deployment/deployment.properties" "/home/$kulad/.java/deployment/deployment.properties.eski"
	touch "$filename"
	echo "deployment.security.use.user.home.java.policy=true" >> "$filename"
	cat "/home/$kulad/.java/deployment/deployment.properties.tmp" >> "$filename"
	
fi
echo "2. Java güvenlik ayarları (exception sites) güncelleniyor."
filename="/home/$kulad/.java/deployment/security/exception.sites"
if test -e  $filename
then
	echo "http://*.meb.gov.tr" >>  "$filename"
	echo "http://dys.meb.gov.tr" >>  "$filename"
	echo "http://dysegitim.meb.gov.tr" >>  "$filename"
	echo "http://dysdownload.meb.gov.tr" >>  "$filename"
	echo "https://dysdownload.meb.gov.tr" >>  "$filename"
	echo "https://dysegitim.meb.gov.tr" >>  "$filename"
	echo "https://dys.meb.gov.tr" >>  "$filename"
	echo "http://tsim.saglik.gov.tr" >>  "$filename"  
	echo "https://tsim.saglik.gov.tr" >>  "$filename" 
	echo "http://tsim1.saglik.gov.tr/tsim2.htm" >>  "$filename" 	
	echo "http://ckys.saglik.gov.tr" >>  "$filename"  
	echo "http://ckyshst.saglik.gov.tr" >>  "$filename"  
	echo "https://tsim1.saglik.gov.tr/tsim2.htm" >>  "$filename" 	
	echo "https://ckys.saglik.gov.tr" >>  "$filename"  
	echo "https://ckyshst.saglik.gov.tr" >>  "$filename" 
    	
else
	touch "$filename"
	echo "http://*.meb.gov.tr" >>  "$filename"
	echo "http://dys.meb.gov.tr" >>  "$filename"
	echo "http://dysegitim.meb.gov.tr" >>  "$filename"
	echo "http://dysdownload.meb.gov.tr" >>  "$filename"
	echo "https://dysdownload.meb.gov.tr" >>  "$filename"
	echo "https://dysegitim.meb.gov.tr" >>  "$filename"
	echo "https://dys.meb.gov.tr" >>  "$filename"  	
	echo "http://tsim.saglik.gov.tr" >>  "$filename"  
	echo "https://tsim.saglik.gov.tr" >>  "$filename" 
	echo "http://tsim1.saglik.gov.tr/tsim2.htm" >>  "$filename" 	
	echo "http://ckys.saglik.gov.tr" >>  "$filename"  
	echo "http://ckyshst.saglik.gov.tr" >>  "$filename" 
	echo "https://tsim1.saglik.gov.tr/tsim2.htm" >>  "$filename" 	
	echo "https://ckys.saglik.gov.tr" >>  "$filename"  
	echo "https://ckyshst.saglik.gov.tr" >>  "$filename"  	
fi

echo "3. Java Policy onarılıyor."
if test -e  $policy
then
	echo "/home/$kulad/.java.policy=true" >>  "$policy"
    	mv "//home/$kulad/.java.policy" "//home/$kulad/.java.policy.eski"
	touch "$policy"
	echo "grant {" >>  "$policy"
	echo "  permission java.security.AllPermission;" >>  "$policy"
	echo "};" >>  "$policy"  	
fi

echo "4. Host ayarları güncelleniyor."
        sudo -ks << EOF
        mv /etc/hosts /etc/hosts.tmp
        touch /etc/hosts
        echo '95.0.196.81    dys.meb.gov.tr' >> /etc/hosts
        echo '95.0.196.79    dysdownload.meb.gov.tr' >> /etc/hosts
        echo '95.0.196.80    dysegitim.meb.gov.tr' >> /etc/hosts
        cat /etc/hosts.tmp >> /etc/hosts

echo "**** İşlemler bitmiştir. DYS yi sorunsuzce kullanabilirsiniz. ****"
